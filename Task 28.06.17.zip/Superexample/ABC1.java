/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Superexample;

/**
 *
 * @author ifbiuser
 */
public class ABC1 extends ABC {
    ABC1(){
        super();
        System.out.println("This is a Child Class");
    }
    void display(){
        System.out.println("Hello");
    }
    public static void main(String[] a){
        ABC1 d = new ABC1();
        d.display();
    }
}
