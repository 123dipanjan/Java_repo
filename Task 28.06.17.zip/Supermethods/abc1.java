/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Supermethods;

/**
 *
 * @author ifbiuser
 */
public class abc1 extends abc{
    
    void display(){
        System.out.println("This is a Child Class");
    }
    void printmsg(){
    
    super.display(); 
    display();
    }
    public static void main(String[] r){
        abc1 h=new abc1();
        h.printmsg();
    }
    
}
